import type * as psi from 'psi_';
declare const _default: () => Promise<psi.Library>;
export default _default;
