export { default } from "./native_node";
