import { PSILibrary } from '../implementation/psi';
import { Loader } from './loader';
type InitOpts = {
    client?: boolean;
    server?: boolean;
};
type Init = (opts: InitOpts) => PSILibrary;
export declare const PSI: (Loader: () => Promise<Loader>) => Promise<Init>;
export {};
