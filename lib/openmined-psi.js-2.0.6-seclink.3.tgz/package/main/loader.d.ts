import * as psi from 'psi_';
export type Loader = {
    readonly library: psi.Library;
};
export declare const createLoader: (bin: () => Promise<psi.Library>) => Promise<Loader>;
