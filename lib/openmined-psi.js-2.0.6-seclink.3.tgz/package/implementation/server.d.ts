import * as psi from 'psi_';
import { Loader } from '../main/loader';
import { Request, Response, ServerSetup } from './proto/psi_pb';
export type Server = {
    readonly delete: () => void;
    readonly createSetupMessage: (fpr: number, numClientInputs: number, inputs: readonly string[], dataStructure?: psi.DataStructure, sortingPermutation?: number[]) => ServerSetup;
    readonly processRequest: (clientRequest: Request) => Response;
    readonly getPrivateKeyBytes: () => Uint8Array;
};
export type ServerWrapper = {
    readonly createWithNewKey: (revealIntersection?: boolean) => Server;
    readonly createFromKey: (key: Uint8Array, revealIntersection?: boolean) => Server;
};
type ServerWrapperOptions = {
    readonly loader: Loader;
};
export type ServerConstructorDependencies = {
    ({ DataStructure }: {
        DataStructure: psi.DataStructure;
    }): ServerWrapper;
};
export declare const ServerWrapperConstructor: ({ loader }: ServerWrapperOptions) => ServerConstructorDependencies;
export {};
