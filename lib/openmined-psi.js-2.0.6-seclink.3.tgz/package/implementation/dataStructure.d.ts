import * as psi from 'psi_';
import { Loader } from '../main/loader';
export type DataStructureWrapper = psi.DataStructure;
type DataStructureWrapperOptions = {
    readonly loader: Loader;
};
export declare const DataStructureWrapperConstructor: ({ loader }: DataStructureWrapperOptions) => DataStructureWrapper;
export {};
