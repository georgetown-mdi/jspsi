export declare const ERROR_INSTANCE_DELETED = "Instance was deleted";
