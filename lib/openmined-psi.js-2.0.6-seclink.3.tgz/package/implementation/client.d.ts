import { Loader } from '../main/loader';
import { Request, Response, ServerSetup } from './proto/psi_pb';
export type Client = {
    readonly delete: () => void;
    readonly createRequest: (clientInputs: readonly string[]) => Request;
    readonly getIntersection: (serverSetup: ServerSetup, serverResponse: Response) => number[];
    readonly getAssociationTable: (serverSetup: ServerSetup, serverResponse: Response) => number[][];
    readonly getIntersectionSize: (serverSetup: ServerSetup, serverResponse: Response) => number;
    readonly getPrivateKeyBytes: () => Uint8Array;
};
export type ClientWrapper = {
    readonly createWithNewKey: (revealIntersection?: boolean) => Client;
    readonly createFromKey: (key: Uint8Array, revealIntersection?: boolean) => Client;
};
type ClientWrapperOptions = {
    readonly loader: Loader;
};
export declare const ClientWrapperConstructor: ({ loader }: ClientWrapperOptions) => ClientWrapper;
export {};
