import { ClientWrapper } from './client';
import { DataStructureWrapper } from './dataStructure';
import { PackageWrapper } from './package';
import { Request, Response, ServerSetup } from './proto/psi_pb';
import { ServerWrapper } from './server';
export type PSILibrary = {
    readonly serverSetup: typeof ServerSetup;
    readonly request: typeof Request;
    readonly response: typeof Response;
    readonly package: PackageWrapper;
    readonly dataStructure: DataStructureWrapper;
    readonly server?: ServerWrapper;
    readonly client?: ClientWrapper;
};
type PSIConstructorOptions = {
    readonly packageWrapper: PackageWrapper;
    readonly dataStructureWrapper: DataStructureWrapper;
    readonly serverWrapper?: ServerWrapper;
    readonly clientWrapper?: ClientWrapper;
};
export declare const PSIConstructor: ({ packageWrapper, dataStructureWrapper, serverWrapper, clientWrapper }: PSIConstructorOptions) => PSILibrary;
export {};
