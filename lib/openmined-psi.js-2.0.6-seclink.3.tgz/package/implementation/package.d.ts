import { Loader } from '../main/loader';
export type Package = {
    readonly version: string;
};
export type PackageWrapper = Package;
type PackageWrapperOptions = {
    readonly loader: Loader;
};
export declare const PackageWrapperConstructor: ({ loader }: PackageWrapperOptions) => PackageWrapper;
export {};
